---Elyon AI Windows---
 + Скачиваете .zip архив сайта
 + Распаковываете всё его содержимое в любую папку
 + Запускаете .exe файл
 + В панели задач кликаете по нему ПКМ - "Закрепить на панели задач"
 + Далее пользуетесь самим приложением без проблем.


---Elyon AI Windows---
+ Download the website's .zip archive
+ Unzip all its contents to any folder
+ Run the .exe file
+ Right-click on it in the taskbar and select "Pin to taskbar"
+ Then use the app without any problems.